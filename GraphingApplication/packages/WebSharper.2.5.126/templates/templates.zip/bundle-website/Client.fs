namespace $safeprojectname$

open IntelliFactory.WebSharper

[<JavaScript>]
module Client =

    let Main =
        JavaScript.Log("Running JavaScript Entry Point..")
